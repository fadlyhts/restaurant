/* eslint-disable no-undef */
Feature('Progressive Web App');

Scenario('Verify web app manifest', async ({ I }) => {
  I.amOnPage('/');
  
  // Verify manifest link
  I.seeElement('link[rel="manifest"]');
  
  // Verify icons
  I.seeElement('link[rel="apple-touch-icon"]');
  
  // Verify theme color
  I.seeElement('meta[name="theme-color"]');
});

Scenario('Verify service worker registration', async ({ I }) => {
  I.amOnPage('/');
  
  // Check if service worker is registered
  I.executeScript(() => {
    return navigator.serviceWorker.getRegistration();
  }).then((registration) => {
    assert.ok(registration, 'Service worker should be registered');
  });
});

Scenario('Verify offline capability', async ({ I }) => {
  I.amOnPage('/');
  
  // Go offline
  I.executeScript(() => {
    return navigator.serviceWorker.ready.then((registration) => {
      registration.active.postMessage({ type: 'OFFLINE' });
    });
  });
  
  // Verify content still accessible
  I.see('Restaurant App');
  I.seeElement('.restaurant-item');
  
  // Go back online
  I.executeScript(() => {
    return navigator.serviceWorker.ready.then((registration) => {
      registration.active.postMessage({ type: 'ONLINE' });
    });
  });
});
