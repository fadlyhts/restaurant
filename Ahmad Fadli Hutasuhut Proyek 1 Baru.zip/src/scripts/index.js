import 'regenerator-runtime';
import '../styles/main.css';
import './components/app-bar.js';
import './components/app-hero.js';
import './components/list-resto.js';
import './components/app-footer.js';
import './components/customer-reviews.js';

document.addEventListener('DOMContentLoaded', () => {
  const drawer = document.querySelector('#drawer');
  const main = document.querySelector('main');
  const navTitle = document.querySelector('.nav__title');

  if (navTitle) {
    navTitle.addEventListener('click', (event) => {
      if (drawer) {
        drawer.classList.toggle('open');
        event.stopPropagation();
      }
    });
  }

  if (main && drawer) {
    main.addEventListener('click', () => {
      drawer.classList.remove('open');
    });
  }

  const skipLink = document.querySelector('.skip-link');
  const mainContent = document.querySelector('#mainContent');
  
  if (skipLink && mainContent) {
      skipLink.addEventListener('click', (e) => {
          e.preventDefault();
          mainContent.focus();
          mainContent.scrollIntoView({behavior: 'smooth'});
      });
  }

  // Mengatur urutan tab
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Tab') {
        const focusableElements = document.querySelectorAll('a, button, input, select, textarea, [tabindex]:not([tabindex="-1"])');
        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];

        if (e.shiftKey && document.activeElement === firstElement) {
            lastElement.focus();
            e.preventDefault();
        } else if (!e.shiftKey && document.activeElement === lastElement) {
            firstElement.focus();
            e.preventDefault();
        }
    }
    });
});

