class AppHero extends HTMLElement {
    connectedCallback() {
        this.render();
    }

    render() {
        this.innerHTML = `
            <div class="hero">
                <div class="hero__inner">
                    <h2 class="hero__title">Discover Great Restaurants</h2>
                    <p class="hero__tagline">Find the best dining experiences in your area</p>
                </div>
            </div>
        `;
    }
}

customElements.define('app-hero', AppHero);
